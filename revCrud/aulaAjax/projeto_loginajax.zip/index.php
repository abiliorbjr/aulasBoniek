<html>
<head>
    <title>Projeto Login com ajax</title>
</head>
<body>
<form id="form" method="POST">
	E-mail:<br/>
	<input type="email" name="email" /><br/><br/>

	Senha:<br/>
	<input type="password" name="password" /><br/><br/>

	<input type="submit" value="Entrar" />
</form>

<script type="text/javascript" src="jquery.min.js"></script>
<script type="text/javascript" src="script.js"></script>
</body>
</html>