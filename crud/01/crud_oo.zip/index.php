<?php
include 'contato.class.php';

$contato = new Contato();